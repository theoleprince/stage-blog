export const ROOT = 'http://localhost:8000/';
export const SERVER = ROOT + 'api/';

export const LOGIN = SERVER + 'auth/token';
   //route pour gestion de vehicules  
export const AUTO = SERVER + 'module-parc/vehicle';  
export const MARQUEAUTO = SERVER + 'module-parc/formes/mark/code';
export const MODELEAUTO = SERVER + 'module-parc/formes/modele/code';
export const TYPEAUTO = SERVER + 'module-parc/formes/type_vehicule/code';
export const CAROSSERIEAUTO = SERVER + 'module-parc/formes/carosserie/code';
 
export const TYPEFICHE = SERVER + 'module-parc/paper_type';
export const ASSURANCE= SERVER + 'module-parc/insurance';
export const OFFICIALPAPER= SERVER + 'module-parc/official_paper';
export const ELEMENTINTERVENANT = SERVER + 'module-parc/intervening_element';
export const VEHICULE = SERVER + 'module-parc/vehicle';
export const TYPENOTIFICATION = SERVER + 'notifications/notification_types';
export const NOTIFICATION = SERVER + 'notifications/notifications';
export const ETAT = SERVER + 'notifications/etats';
export const AFFECTATION = SERVER + 'module-parc/affectation';
export const VEHICULEALL = SERVER + 'module-parc/vehicle/all/get';
export const DRIVERALL = SERVER + 'module-parc/driver/all/get';
export const FORM = SERVER + 'module-parc/formes';
export const DOCUMENT = SERVER + 'module-document/document';
export const TYPEINTERVENANT = SERVER + 'module-parc/intervening_type';

export const SANCTION = SERVER + 'module-rh/sanction';
export const TYPE_SANCTION = SERVER + 'module-rh/sanction-type';
export const CONTRAT = SERVER + 'module-rh/contract';
export const TYPE_CONTRAT = SERVER + 'module-rh/contract-type';
export const USER = SERVER + 'users';
export const NOTECRITIQUE = SERVER + 'module-rh/internal-note';
export const FORMATION = SERVER + 'module-rh/formation';
export const CHAUFFEUR = SERVER + 'module-parc/driver';

